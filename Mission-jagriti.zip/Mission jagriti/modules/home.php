
<!-- Hero Banner Slider -->
<section class="hero-banner position-relative bg-light" style="min-height: 60vh; background: linear-gradient(120deg, #184d27 60%, #ff9933 100%);">
  <div class="container py-5 text-center text-white">
    <img src="assets/img/logo.png" alt="Mission Jagriti" height="80" class="mb-3">
    <h1 class="display-4 fw-bold">Mission Jagriti</h1>
    <p class="lead mb-4">एक जागरूक समाज, एक सशक्त भविष्य</p>
    <div class="mb-4">
      <a href="?page=donate" class="btn btn-success btn-lg me-2">Donate Now</a>
      <a href="?page=volunteer" class="btn btn-outline-light btn-lg me-2">Join Volunteer</a>
      <a href="?page=membership" class="btn btn-warning btn-lg">Become Member</a>
    </div>
  </div>
</section>

<!-- About Mission Jagriti -->
<section class="py-5 bg-white">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-6 mb-4 mb-md-0">
        <img src="assets/img/about.jpg" alt="About Mission Jagriti" class="img-fluid rounded shadow">
      </div>
      <div class="col-md-6">
        <h2 class="fw-bold mb-3 text-success">About Mission Jagriti</h2>
        <p>Mission Jagriti is a national-level NGO dedicated to empowering communities through education, health, women empowerment, youth development, environment, and social awareness. We believe in creating a conscious society for a stronger future.</p>
        <a href="?page=about" class="btn btn-success mt-2">Read More</a>
      </div>
    </div>
  </div>
</section>

<!-- Mission & Vision -->
<section class="py-5" style="background: #f8f5ef;">
  <div class="container">
    <div class="row text-center">
      <div class="col-md-6 mb-4 mb-md-0">
        <div class="p-4 bg-white rounded shadow h-100">
          <h3 class="text-success">Our Mission</h3>
          <p>To inspire, educate, and empower individuals and communities for sustainable development and social change.</p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="p-4 bg-white rounded shadow h-100">
          <h3 class="text-warning">Our Vision</h3>
          <p>A just, aware, and empowered society where every individual has the opportunity to thrive and contribute.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Focus Areas -->
<section class="py-5 bg-white">
  <div class="container">
    <h2 class="text-center fw-bold mb-5">Our Focus Areas</h2>
    <div class="row g-4 text-center">
      <div class="col-6 col-md-4 col-lg-2">
        <div class="p-3 bg-light rounded shadow-sm h-100">
          <i class="fas fa-graduation-cap fa-2x text-success mb-2"></i>
          <h6>Education</h6>
        </div>
      </div>
      <div class="col-6 col-md-4 col-lg-2">
        <div class="p-3 bg-light rounded shadow-sm h-100">
          <i class="fas fa-heartbeat fa-2x text-danger mb-2"></i>
          <h6>Health</h6>
        </div>
      </div>
      <div class="col-6 col-md-4 col-lg-2">
        <div class="p-3 bg-light rounded shadow-sm h-100">
          <i class="fas fa-female fa-2x text-warning mb-2"></i>
          <h6>Women Empowerment</h6>
        </div>
      </div>
      <div class="col-6 col-md-4 col-lg-2">
        <div class="p-3 bg-light rounded shadow-sm h-100">
          <i class="fas fa-users fa-2x text-primary mb-2"></i>
          <h6>Youth Development</h6>
        </div>
      </div>
      <div class="col-6 col-md-4 col-lg-2">
        <div class="p-3 bg-light rounded shadow-sm h-100">
          <i class="fas fa-leaf fa-2x text-success mb-2"></i>
          <h6>Environment</h6>
        </div>
      </div>
      <div class="col-6 col-md-4 col-lg-2">
        <div class="p-3 bg-light rounded shadow-sm h-100">
          <i class="fas fa-bullhorn fa-2x text-orange mb-2"></i>
          <h6>Social Awareness</h6>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Impact Counters -->
<section class="py-5" style="background: linear-gradient(90deg, #184d27 70%, #ff9933 100%);">
  <div class="container">
    <div class="row text-center text-white">
      <div class="col-6 col-md-3 mb-4 mb-md-0">
        <div class="p-4 bg-success bg-opacity-75 rounded shadow">
          <h2 class="fw-bold mb-1" id="counter-volunteers">500+</h2>
          <p>Volunteers</p>
        </div>
      </div>
      <div class="col-6 col-md-3 mb-4 mb-md-0">
        <div class="p-4 bg-warning bg-opacity-75 rounded shadow">
          <h2 class="fw-bold mb-1" id="counter-events">120+</h2>
          <p>Events</p>
        </div>
      </div>
      <div class="col-6 col-md-3 mb-4 mb-md-0">
        <div class="p-4 bg-primary bg-opacity-75 rounded shadow">
          <h2 class="fw-bold mb-1" id="counter-beneficiaries">10,000+</h2>
          <p>Beneficiaries</p>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="p-4 bg-danger bg-opacity-75 rounded shadow">
          <h2 class="fw-bold mb-1" id="counter-campaigns">30+</h2>
          <p>Campaigns</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Latest News & Updates -->
<section class="py-5 bg-white">
  <div class="container">
    <h2 class="text-center fw-bold mb-5">Latest News & Updates</h2>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card h-100 shadow-sm">
          <img src="assets/img/blog1.jpg" class="card-img-top" alt="News 1">
          <div class="card-body">
            <h5 class="card-title">Mission Jagriti Launches New Campaign</h5>
            <p class="card-text">We are excited to announce our new campaign for 2026...</p>
            <a href="?page=blog" class="btn btn-link">Read More</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card h-100 shadow-sm">
          <img src="assets/img/blog2.jpg" class="card-img-top" alt="News 2">
          <div class="card-body">
            <h5 class="card-title">Health Camp Impact</h5>
            <p class="card-text">Our recent health camp benefited over 300 people in Town B.</p>
            <a href="?page=blog" class="btn btn-link">Read More</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card h-100 shadow-sm">
          <img src="assets/img/blog3.jpg" class="card-img-top" alt="News 3">
          <div class="card-body">
            <h5 class="card-title">Education for All</h5>
            <p class="card-text">Distributed school kits to 500+ children in Village A.</p>
            <a href="?page=blog" class="btn btn-link">Read More</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Upcoming Events -->
<section class="py-5" style="background: #f8f5ef;">
  <div class="container">
    <h2 class="text-center fw-bold mb-5">Upcoming Events</h2>
    <div class="row g-4">
      <div class="col-md-6">
        <div class="card shadow-sm h-100">
          <div class="card-body">
            <h5 class="card-title">Annual Fundraiser</h5>
            <p class="card-text">Join us for our annual fundraising event. <br><b>Date:</b> 20 June 2026 <br><b>Location:</b> City Hall</p>
            <a href="?page=events" class="btn btn-success">Register</a>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card shadow-sm h-100">
          <div class="card-body">
            <h5 class="card-title">Tree Plantation Drive</h5>
            <p class="card-text">Let’s make our city greener! <br><b>Date:</b> 12 March 2026 <br><b>Location:</b> Central Park</p>
            <a href="?page=events" class="btn btn-success">Register</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Gallery Preview -->
<section class="py-5 bg-white">
  <div class="container">
    <h2 class="text-center fw-bold mb-5">Gallery</h2>
    <div class="row g-4">
      <div class="col-6 col-md-3">
        <img src="assets/img/gallery1.jpg" class="img-fluid rounded shadow-sm" alt="Gallery 1">
      </div>
      <div class="col-6 col-md-3">
        <img src="assets/img/gallery2.jpg" class="img-fluid rounded shadow-sm" alt="Gallery 2">
      </div>
      <div class="col-6 col-md-3">
        <img src="assets/img/gallery3.jpg" class="img-fluid rounded shadow-sm" alt="Gallery 3">
      </div>
      <div class="col-6 col-md-3">
        <img src="assets/img/gallery4.jpg" class="img-fluid rounded shadow-sm" alt="Gallery 4">
      </div>
    </div>
    <div class="text-center mt-4">
      <a href="?page=gallery" class="btn btn-outline-success">View Full Gallery</a>
    </div>
  </div>
</section>

<!-- Founder Message -->
<section class="py-5" style="background: #f8f5ef;">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-3 mb-4 mb-md-0 text-center">
        <img src="assets/img/founder.jpg" alt="Founder" class="img-fluid rounded-circle shadow" style="max-width: 150px;">
      </div>
      <div class="col-md-9">
        <h3 class="fw-bold text-success mb-1">Message from the Founder</h3>
        <p class="mb-0">“Together, we can create a society where everyone has the opportunity to grow, learn, and lead. Thank you for supporting Mission Jagriti.”<br><b>- Sunita Sharma, Founder</b></p>
      </div>
    </div>
  </div>
</section>

<!-- Testimonials -->
<section class="py-5 bg-white">
  <div class="container">
    <h2 class="text-center fw-bold mb-5">Testimonials</h2>
    <div class="row g-4 justify-content-center">
      <div class="col-md-4">
        <div class="card shadow-sm h-100">
          <div class="card-body">
            <p class="card-text">“Mission Jagriti changed my life!”</p>
            <div class="d-flex align-items-center mt-3">
              <img src="assets/img/testimonial1.jpg" alt="Ravi Kumar" class="rounded-circle me-3" width="48">
              <div>
                <h6 class="mb-0">Ravi Kumar</h6>
                <small>Beneficiary</small>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card shadow-sm h-100">
          <div class="card-body">
            <p class="card-text">“I am proud to be a volunteer with Mission Jagriti.”</p>
            <div class="d-flex align-items-center mt-3">
              <img src="assets/img/testimonial2.jpg" alt="Priya Singh" class="rounded-circle me-3" width="48">
              <div>
                <h6 class="mb-0">Priya Singh</h6>
                <small>Volunteer</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Volunteer Call-to-Action Banner -->
<section class="py-5 text-white text-center" style="background: linear-gradient(90deg, #ff9933 60%, #184d27 100%);">
  <div class="container">
    <h2 class="fw-bold mb-3">Become a Volunteer</h2>
    <p class="mb-4">Join us in making a difference! Your time and skills can change lives.</p>
    <a href="?page=volunteer" class="btn btn-light btn-lg">Join Now</a>
  </div>
</section>

<!-- Donation Banner -->
<section class="py-5 bg-success bg-gradient text-white text-center">
  <div class="container">
    <h2 class="fw-bold mb-3">Support Our Mission</h2>
    <p class="mb-4">Your donation helps us reach more people and create lasting impact.</p>
    <a href="?page=donate" class="btn btn-warning btn-lg">Donate Now</a>
  </div>
</section>
