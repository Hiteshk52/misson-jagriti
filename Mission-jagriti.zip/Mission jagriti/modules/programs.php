<?php
require_once __DIR__ . '/../config/config.php';
// Fetch categories
$catStmt = $pdo->query('SELECT * FROM categories ORDER BY name');
$categories = $catStmt->fetchAll();
// Fetch programs (latest 12)
$progStmt = $pdo->query('SELECT p.*, c.name as category FROM programs p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.date DESC LIMIT 12');
$programs = $progStmt->fetchAll();
?>
<section class="py-5 bg-white">
  <div class="container">
    <h1 class="fw-bold text-success mb-4 text-center">Our Programs & Initiatives</h1>
    <div class="mb-4 text-center">
      <span class="me-2">Filter by Category:</span>
      <a href="?page=programs" class="btn btn-outline-success btn-sm me-1 mb-1">All</a>
      <?php foreach ($categories as $cat): ?>
        <a href="?page=programs&cat=<?php echo $cat['id']; ?>" class="btn btn-outline-success btn-sm me-1 mb-1"><?php echo htmlspecialchars($cat['name']); ?></a>
      <?php endforeach; ?>
    </div>
    <div class="row g-4">
      <?php if ($programs): foreach ($programs as $prog): ?>
        <div class="col-md-4">
          <div class="card h-100 shadow-sm">
            <img src="<?php echo htmlspecialchars($prog['banner'] ?: 'assets/img/program_default.jpg'); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($prog['title']); ?>">
            <div class="card-body">
              <span class="badge bg-success mb-2"><?php echo htmlspecialchars($prog['category']); ?></span>
              <h5 class="card-title"><?php echo htmlspecialchars($prog['title']); ?></h5>
              <p class="card-text"><?php echo htmlspecialchars(mb_strimwidth($prog['description'], 0, 100, '...')); ?></p>
              <ul class="list-unstyled small mb-2">
                <li><i class="fa fa-calendar me-1"></i> <?php echo htmlspecialchars($prog['date']); ?></li>
                <li><i class="fa fa-map-marker-alt me-1"></i> <?php echo htmlspecialchars($prog['location']); ?></li>
                <li><i class="fa fa-chart-line me-1"></i> Impact: <?php echo htmlspecialchars($prog['impact_numbers']); ?></li>
              </ul>
              <a href="#" class="btn btn-outline-success btn-sm disabled">View Details</a>
            </div>
          </div>
        </div>
      <?php endforeach; else: ?>
        <div class="col-12 text-center">
          <div class="alert alert-warning">No programs found.</div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
