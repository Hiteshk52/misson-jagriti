<section class="py-5 bg-white">
  <div class="container">
    <div class="row align-items-center mb-5">
      <div class="col-md-6 mb-4 mb-md-0">
        <img src="assets/img/about.jpg" alt="About Mission Jagriti" class="img-fluid rounded shadow">
      </div>
      <div class="col-md-6">
        <h1 class="fw-bold text-success mb-3">About Mission Jagriti</h1>
        <p>Mission Jagriti is a national-level NGO dedicated to empowering communities through education, health, women empowerment, youth development, environment, and social awareness. We believe in creating a conscious society for a stronger future.</p>
      </div>
    </div>
    <div class="row mb-5">
      <div class="col-md-4">
        <div class="p-4 bg-light rounded shadow-sm h-100">
          <h4 class="text-success">Our History</h4>
          <p>Founded in 2010, Mission Jagriti has impacted thousands of lives through its grassroots initiatives and community-driven programs.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-4 bg-light rounded shadow-sm h-100">
          <h4 class="text-warning">Vision</h4>
          <p>A just, aware, and empowered society where every individual has the opportunity to thrive and contribute.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-4 bg-light rounded shadow-sm h-100">
          <h4 class="text-primary">Mission</h4>
          <p>To inspire, educate, and empower individuals and communities for sustainable development and social change.</p>
        </div>
      </div>
    </div>
    <div class="row mb-5">
      <div class="col-md-6 mb-4 mb-md-0">
        <div class="p-4 bg-white rounded shadow-sm h-100">
          <h4 class="text-success">Core Values</h4>
          <ul class="list-unstyled mb-0">
            <li><i class="fa fa-check text-success me-2"></i>Integrity & Transparency</li>
            <li><i class="fa fa-check text-success me-2"></i>Inclusivity</li>
            <li><i class="fa fa-check text-success me-2"></i>Empowerment</li>
            <li><i class="fa fa-check text-success me-2"></i>Collaboration</li>
            <li><i class="fa fa-check text-success me-2"></i>Innovation</li>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="p-4 bg-white rounded shadow-sm h-100">
          <h4 class="text-warning">Founder Message</h4>
          <div class="d-flex align-items-center mb-2">
            <img src="assets/img/founder.jpg" alt="Founder" class="rounded-circle me-3" width="56">
            <div>
              <strong>Sunita Sharma</strong><br>
              <small>Founder, Mission Jagriti</small>
            </div>
          </div>
          <p class="mb-0">“Together, we can create a society where everyone has the opportunity to grow, learn, and lead. Thank you for supporting Mission Jagriti.”</p>
        </div>
      </div>
    </div>
    <div class="row mb-5">
      <div class="col-md-6 mb-4 mb-md-0">
        <div class="p-4 bg-light rounded shadow-sm h-100">
          <h4 class="text-success">Team Members</h4>
          <ul class="list-unstyled mb-0">
            <li><strong>Sunita Sharma</strong> – Founder</li>
            <li><strong>Ravi Kumar</strong> – Program Manager</li>
            <li><strong>Priya Singh</strong> – Volunteer Lead</li>
            <li><strong>Ajay Mehta</strong> – Finance Head</li>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="p-4 bg-light rounded shadow-sm h-100">
          <h4 class="text-warning">Registration & Certificates</h4>
          <ul class="list-unstyled mb-0">
            <li><i class="fa fa-certificate text-warning me-2"></i>Registered under Societies Act</li>
            <li><i class="fa fa-certificate text-warning me-2"></i>12A & 80G Certified</li>
            <li><i class="fa fa-certificate text-warning me-2"></i>NGO Darpan Registered</li>
          </ul>
          <a href="assets/certificates/registration.pdf" class="btn btn-outline-success btn-sm mt-2" target="_blank">View Certificate</a>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="p-4 bg-white rounded shadow-sm text-center">
          <h4 class="text-success mb-3">Our Commitment</h4>
          <p>Mission Jagriti is committed to transparency, accountability, and sustainable impact. We invite you to join us in our journey towards a better tomorrow.</p>
        </div>
      </div>
    </div>
  </div>
</section>
