</main>
<footer class="bg-dark text-light pt-5 pb-3 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-3">
                <img src="assets/img/logo.png" alt="Mission Jagriti" height="48" class="mb-2">
                <p>एक जागरूक समाज, एक सशक्त भविष्य</p>
                <div class="mb-2">
                    <a href="#" class="text-light me-2"><i class="fab fa-facebook fa-lg"></i></a>
                    <a href="#" class="text-light me-2"><i class="fab fa-twitter fa-lg"></i></a>
                    <a href="#" class="text-light me-2"><i class="fab fa-instagram fa-lg"></i></a>
                    <a href="#" class="text-light me-2"><i class="fab fa-youtube fa-lg"></i></a>
                    <a href="#" class="text-light"><i class="fab fa-whatsapp fa-lg"></i></a>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <h6>Quick Links</h6>
                <ul class="list-unstyled">
                    <li><a href="./" class="text-light">Home</a></li>
                    <li><a href="?page=about" class="text-light">About</a></li>
                    <li><a href="?page=programs" class="text-light">Programs</a></li>
                    <li><a href="?page=events" class="text-light">Events</a></li>
                    <li><a href="?page=gallery" class="text-light">Gallery</a></li>
                </ul>
            </div>
            <div class="col-md-3 mb-3">
                <h6>Contact</h6>
                <p class="mb-1"><i class="fa fa-map-marker-alt me-2"></i>123, Main Road, City, India</p>
                <p class="mb-1"><i class="fa fa-envelope me-2"></i>info@missionjagriti.org</p>
                <p><i class="fa fa-phone me-2"></i>+91-9876543210</p>
            </div>
            <div class="col-md-3 mb-3">
                <h6>Newsletter</h6>
                <form class="d-flex" method="post" action="#">
                    <input type="email" class="form-control me-2" name="newsletter_email" placeholder="Your email" required>
                    <button class="btn btn-success" type="submit">Subscribe</button>
                </form>
            </div>
        </div>
        <div class="text-center mt-3">
            <small>&copy; <?php echo date('Y'); ?> Mission Jagriti. All rights reserved.</small>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>