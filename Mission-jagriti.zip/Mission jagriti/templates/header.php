<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mission Jagriti</title>
    <meta name="description" content="Mission Jagriti - एक जागरूक समाज, एक सशक्त भविष्य">
    <link rel="icon" href="assets/img/favicon.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="./">
                <img src="assets/img/logo.png" alt="Mission Jagriti" height="48" class="me-2">
                <span class="fw-bold text-success">Mission Jagriti</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="./">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="?page=about">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="?page=programs">Programs</a></li>
                    <li class="nav-item"><a class="nav-link" href="?page=events">Events</a></li>
                    <li class="nav-item"><a class="nav-link" href="?page=gallery">Gallery</a></li>
                    <li class="nav-item"><a class="nav-link" href="?page=blog">Blog</a></li>
                    <li class="nav-item"><a class="nav-link" href="?page=donate">Donate</a></li>
                    <li class="nav-item"><a class="nav-link" href="?page=volunteer">Volunteer</a></li>
                    <li class="nav-item"><a class="nav-link" href="?page=membership">Membership</a></li>
                    <li class="nav-item"><a class="nav-link" href="?page=magazine">Magazine</a></li>
                    <li class="nav-item"><a class="nav-link" href="?page=contact">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<main class="flex-shrink-0">