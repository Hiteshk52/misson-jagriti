<?php
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }
require_once '../config/config.php';
// Delete volunteer
if (isset($_POST['delete'])) {
    $stmt = $pdo->prepare('DELETE FROM volunteers WHERE id = ?');
    $stmt->execute([$_POST['id']]);
}
$volunteers = $pdo->query('SELECT * FROM volunteers ORDER BY registered_at DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Volunteers - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
    <h2>Volunteers</h2>
    <table class="table table-bordered table-striped">
        <thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>City</th><th>Skills</th><th>Availability</th><th>Message</th><th>Registered</th><th>Action</th></tr></thead>
        <tbody>
        <?php foreach ($volunteers as $v): ?>
            <tr>
                <td><?php echo htmlspecialchars($v['name']); ?></td>
                <td><?php echo htmlspecialchars($v['phone']); ?></td>
                <td><?php echo htmlspecialchars($v['email']); ?></td>
                <td><?php echo htmlspecialchars($v['city']); ?></td>
                <td><?php echo htmlspecialchars($v['skills']); ?></td>
                <td><?php echo htmlspecialchars($v['availability']); ?></td>
                <td><?php echo htmlspecialchars($v['message']); ?></td>
                <td><?php echo htmlspecialchars($v['registered_at']); ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="id" value="<?php echo $v['id']; ?>">
                        <button class="btn btn-danger btn-sm" name="delete" onclick="return confirm('Delete this volunteer?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <a href="dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
</div>
</body>
</html>
