<?php
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }
require_once '../config/config.php';
// Handle add/edit/delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $subtitle = $_POST['subtitle'] ?? '';
    $button_text = $_POST['button_text'] ?? '';
    $button_link = $_POST['button_link'] ?? '';
    $image = $_POST['image'] ?? '';
    if (isset($_POST['add'])) {
        $stmt = $pdo->prepare('INSERT INTO sliders (image, title, subtitle, button_text, button_link) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$image, $title, $subtitle, $button_text, $button_link]);
    } elseif (isset($_POST['delete'])) {
        $stmt = $pdo->prepare('DELETE FROM sliders WHERE id = ?');
        $stmt->execute([$_POST['id']]);
    }
}
$sliders = $pdo->query('SELECT * FROM sliders ORDER BY id DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Sliders - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
    <h2>Manage Sliders</h2>
    <form method="post" class="row g-2 mb-4">
        <div class="col-md-2"><input type="text" name="title" class="form-control" placeholder="Title" required></div>
        <div class="col-md-2"><input type="text" name="subtitle" class="form-control" placeholder="Subtitle"></div>
        <div class="col-md-2"><input type="text" name="button_text" class="form-control" placeholder="Button Text"></div>
        <div class="col-md-2"><input type="text" name="button_link" class="form-control" placeholder="Button Link"></div>
        <div class="col-md-2"><input type="text" name="image" class="form-control" placeholder="Image URL" required></div>
        <div class="col-md-2"><button class="btn btn-success w-100" name="add">Add Slider</button></div>
    </form>
    <table class="table table-bordered table-striped">
        <thead><tr><th>Image</th><th>Title</th><th>Subtitle</th><th>Button</th><th>Action</th></tr></thead>
        <tbody>
        <?php foreach ($sliders as $s): ?>
            <tr>
                <td><img src="../<?php echo htmlspecialchars($s['image']); ?>" height="40"></td>
                <td><?php echo htmlspecialchars($s['title']); ?></td>
                <td><?php echo htmlspecialchars($s['subtitle']); ?></td>
                <td><?php echo htmlspecialchars($s['button_text']); ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="id" value="<?php echo $s['id']; ?>">
                        <button class="btn btn-danger btn-sm" name="delete" onclick="return confirm('Delete this slider?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <a href="dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
</div>
</body>
</html>
