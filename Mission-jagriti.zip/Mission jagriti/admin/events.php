<?php
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }
require_once '../config/config.php';
// Delete event
if (isset($_POST['delete'])) {
    $stmt = $pdo->prepare('DELETE FROM events WHERE id = ?');
    $stmt->execute([$_POST['id']]);
}
$events = $pdo->query('SELECT * FROM events ORDER BY date DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Events - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
    <h2>Events</h2>
    <table class="table table-bordered table-striped">
        <thead><tr><th>Title</th><th>Date</th><th>Location</th><th>Upcoming?</th><th>Action</th></tr></thead>
        <tbody>
        <?php foreach ($events as $e): ?>
            <tr>
                <td><?php echo htmlspecialchars($e['title']); ?></td>
                <td><?php echo htmlspecialchars($e['date']); ?></td>
                <td><?php echo htmlspecialchars($e['location']); ?></td>
                <td><?php echo $e['is_upcoming'] ? 'Yes' : 'No'; ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="id" value="<?php echo $e['id']; ?>">
                        <button class="btn btn-danger btn-sm" name="delete" onclick="return confirm('Delete this event?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <a href="dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
</div>
</body>
</html>
