<?php
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }
require_once '../config/config.php';
// Delete gallery item
if (isset($_POST['delete'])) {
    $stmt = $pdo->prepare('DELETE FROM gallery WHERE id = ?');
    $stmt->execute([$_POST['id']]);
}
$gallery = $pdo->query('SELECT * FROM gallery ORDER BY uploaded_at DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Gallery - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
    <h2>Gallery</h2>
    <table class="table table-bordered table-striped">
        <thead><tr><th>Type</th><th>Album</th><th>Title</th><th>File</th><th>Uploaded</th><th>Action</th></tr></thead>
        <tbody>
        <?php foreach ($gallery as $g): ?>
            <tr>
                <td><?php echo htmlspecialchars($g['type']); ?></td>
                <td><?php echo htmlspecialchars($g['album']); ?></td>
                <td><?php echo htmlspecialchars($g['title']); ?></td>
                <td><a href="../<?php echo htmlspecialchars($g['file']); ?>" target="_blank">View</a></td>
                <td><?php echo htmlspecialchars($g['uploaded_at']); ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="id" value="<?php echo $g['id']; ?>">
                        <button class="btn btn-danger btn-sm" name="delete" onclick="return confirm('Delete this item?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <a href="dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
</div>
</body>
</html>
