<?php
session_start();
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }
require_once '../config/config.php';
// Delete member
if (isset($_POST['delete'])) {
    $stmt = $pdo->prepare('DELETE FROM members WHERE id = ?');
    $stmt->execute([$_POST['id']]);
}
$members = $pdo->query('SELECT m.*, u.name, u.email, u.phone, u.city FROM members m LEFT JOIN users u ON m.user_id = u.id ORDER BY m.joined_at DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Members - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
    <h2>Members</h2>
    <table class="table table-bordered table-striped">
        <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>City</th><th>Membership ID</th><th>Joined</th><th>Action</th></tr></thead>
        <tbody>
        <?php foreach ($members as $m): ?>
            <tr>
                <td><?php echo htmlspecialchars($m['name']); ?></td>
                <td><?php echo htmlspecialchars($m['email']); ?></td>
                <td><?php echo htmlspecialchars($m['phone']); ?></td>
                <td><?php echo htmlspecialchars($m['city']); ?></td>
                <td><?php echo htmlspecialchars($m['membership_id']); ?></td>
                <td><?php echo htmlspecialchars($m['joined_at']); ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                        <button class="btn btn-danger btn-sm" name="delete" onclick="return confirm('Delete this member?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <a href="dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
</div>
</body>
</html>
