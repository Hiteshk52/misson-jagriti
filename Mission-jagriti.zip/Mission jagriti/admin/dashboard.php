<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit;
}
require_once '../config/config.php';
// Dashboard analytics (sample)
$volunteers = $pdo->query('SELECT COUNT(*) FROM volunteers')->fetchColumn();
$events = $pdo->query('SELECT COUNT(*) FROM events')->fetchColumn();
$beneficiaries = 1200; // Example static, replace with real logic
$campaigns = $pdo->query('SELECT COUNT(*) FROM programs')->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Mission Jagriti</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body{background:#f8f5ef;}</style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark px-3">
    <a class="navbar-brand" href="#">Mission Jagriti Admin</a>
    <a href="logout.php" class="btn btn-outline-light">Logout</a>
</nav>
<div class="container-fluid mt-4">
    <div class="row">
        <aside class="col-md-2 bg-white shadow-sm p-0">
            <ul class="nav flex-column py-3">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Manage Homepage</a></li>
                <li class="nav-item"><a class="nav-link" href="sliders.php">Sliders</a></li>
                <li class="nav-item"><a class="nav-link" href="blogs.php">Blogs</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Programs</a></li>
                <li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="volunteers.php">Volunteers</a></li>
                <li class="nav-item"><a class="nav-link" href="members.php">Members</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Donations</a></li>
                <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
                <li class="nav-item"><a class="nav-link" href="#">PDFs</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Testimonials</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Team</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Settings</a></li>
                <li class="nav-item"><a class="nav-link" href="#">SEO</a></li>
            </ul>
        </aside>
        <main class="col-md-10">
            <h2 class="mt-3">Dashboard</h2>
            <div class="row mt-4">
                <div class="col-md-3 mb-3">
                    <div class="card text-center shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Volunteers</h5>
                            <p class="display-6 fw-bold text-success"><?php echo $volunteers; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-center shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Events</h5>
                            <p class="display-6 fw-bold text-primary"><?php echo $events; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-center shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Beneficiaries</h5>
                            <p class="display-6 fw-bold text-warning"><?php echo $beneficiaries; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-center shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Campaigns</h5>
                            <p class="display-6 fw-bold text-danger"><?php echo $campaigns; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- More analytics/widgets here -->
        </main>
    </div>
</div>
</body>
</html>
