-- Sample Data for Mission Jagriti

INSERT INTO admins (username, password, email) VALUES
('admin', '$2y$10$examplehashedpassword', 'admin@missionjagriti.org');

INSERT INTO categories (name) VALUES
('Education'), ('Health Camps'), ('Career Guidance'), ('Women Empowerment'), ('Environment Campaigns'), ('Youth Activities'), ('Social Awareness Drives'), ('News'), ('Events');

INSERT INTO settings (meta_title, meta_description, og_image, logo, favicon, contact_email, contact_phone, address, facebook, twitter, instagram, youtube, whatsapp, newsletter_email) VALUES
('Mission Jagriti - Empowering Society', 'Mission Jagriti is a national-level NGO working for education, health, women empowerment, youth, and environment.', 'assets/img/og-image.jpg', 'assets/img/logo.png', 'assets/img/favicon.ico', 'info@missionjagriti.org', '+91-9876543210', '123, Main Road, City, State, India', 'https://facebook.com/missionjagriti', 'https://twitter.com/missionjagriti', 'https://instagram.com/missionjagriti', 'https://youtube.com/missionjagriti', 'https://wa.me/919876543210', 'newsletter@missionjagriti.org');

INSERT INTO sliders (image, title, subtitle, button_text, button_link) VALUES
('assets/img/slider1.jpg', 'Empowering Communities', 'Together for a better tomorrow', 'Donate Now', 'donate'),
('assets/img/slider2.jpg', 'Education for All', 'Transforming lives through learning', 'Join Volunteer', 'volunteer');

INSERT INTO programs (category_id, title, description, banner, impact_numbers, date, location) VALUES
(1, 'School Kit Distribution', 'Distributed school kits to underprivileged children.', 'assets/img/program1.jpg', '500+ children', '2026-01-15', 'Village A'),
(2, 'Free Health Camp', 'Organized a free health checkup camp.', 'assets/img/program2.jpg', '300+ beneficiaries', '2026-02-10', 'Town B');

INSERT INTO events (title, description, banner, date, location, is_upcoming) VALUES
('Annual Fundraiser', 'Join us for our annual fundraising event.', 'assets/img/event1.jpg', '2026-06-20', 'City Hall', 1),
('Tree Plantation Drive', 'Let’s make our city greener!', 'assets/img/event2.jpg', '2026-03-12', 'Central Park', 0);

INSERT INTO gallery (type, album, file, title) VALUES
('photo', 'Education', 'assets/img/gallery1.jpg', 'Children receiving school kits'),
('photo', 'Health', 'assets/img/gallery2.jpg', 'Doctors at health camp');

INSERT INTO blogs (category_id, title, slug, content, featured_image) VALUES
(8, 'Mission Jagriti Launches New Campaign', 'mission-jagriti-new-campaign', 'We are excited to announce our new campaign for 2026...', 'assets/img/blog1.jpg');

INSERT INTO testimonials (name, message, image) VALUES
('Ravi Kumar', 'Mission Jagriti changed my life!', 'assets/img/testimonial1.jpg');

INSERT INTO team_members (name, designation, image, bio) VALUES
('Sunita Sharma', 'Founder', 'assets/img/founder.jpg', 'Sunita is the visionary behind Mission Jagriti.');

INSERT INTO magazines (title, file, month, year) VALUES
('Mission Jagriti Magazine - Jan 2026', 'uploads/magazine_jan2026.pdf', 'January', 2026);

-- Add more sample data as needed
