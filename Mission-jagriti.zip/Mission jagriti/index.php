<?php
require_once __DIR__ . '/config/config.php';
// Simple router for main pages
$page = $_GET['page'] ?? 'home';
$allowed = ['home','about','programs','events','gallery','blog','donate','volunteer','membership','magazine','contact'];
if (!in_array($page, $allowed)) $page = 'home';
include __DIR__ . '/templates/header.php';
include __DIR__ . "/modules/{$page}.php";
include __DIR__ . '/templates/footer.php';
